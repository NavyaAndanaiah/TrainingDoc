﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ticketbook
{
    public partial class Ticket
    {
        private static int ticketId = 1000;
        int Ticketid
        {
            get
            {
                return ticketId;
            }
            set
            {
                ticketId = value;
            }
        }
        private int theatreName;
        public int TheatreName
        {
            get
            {
                return theatreName;
            }
            set
            {
                theatreName = value;
            }
        }
        private int movieName;
        public int MovieName
        {
            get
            {
                return movieName;
            }
            set
            {
                movieName = value;
            }
        }
        private DateTime showDetails;
        public DateTime ShowDetails
        {
            get
            {
                return showDetails;
            }
            set
            {
                showDetails = value;
            }
        }

        private DateTime showDate;
        public DateTime ShowDate
        {
            get
            {
                return showDate;
            }
            set
            {
                showDate = value;
            }
        }

        private DateTime showTime;
        public DateTime ShowTime
        {
            get
            {
                return showTime;
            }
            set
            {
                showTime = value;
            }
        }
        private int seatNo;
        int Seatno
        {
            get
            {
                return seatNo;
            }
            set
            {
                seatNo = value;
            }
        }
        private int numberofSeats;
        public int NumberofSeats
        {
            get
            {
                return numberofSeats;
            }
            set
            {
                numberofSeats = value;
            }
        }
        public int OrdrId;
        public Ticket()
        { }
        internal void ticketdetails(List<Ticket> t)
        {
            int check = 0;
            int ticketAmount = 0;
            string nameTheatre = "";
            string nameMovie = "";
            foreach (Ticket tic in t)
            {
                Console.WriteLine("Ticket id is\t{0}", tic.Ticketid);
                Console.WriteLine("Orderid \t{0}", tic.OrdrId);
                if (tic.TheatreName == 1)
                {
                    nameTheatre = "SANJAYA";
                    ticketAmount = 100;
                }
                else if (tic.TheatreName == 2)
                {
                    nameTheatre = "PVRCINEMAS";
                    ticketAmount = 150;
                }
                else if (tic.TheatreName == 3)
                {
                    nameTheatre = "INOX";
                    ticketAmount = 130;
                }
                Console.WriteLine("Theatre name \t {0}", nameTheatre);
                if (tic.MovieName == 1)
                    nameMovie = "Beauty and the Beast";
                else if (tic.MovieName == 2)
                    nameMovie = "Boss Baby";
                else if (tic.MovieName == 3)
                    nameMovie = "XXX";
                Console.WriteLine("Movie Name \t {0}", nameMovie);
                Console.WriteLine("No of tickets ordered\t{0}", tic.NumberofSeats);
                Console.WriteLine("Amount for tickets: {0}", ticketAmount * tic.NumberofSeats);
                check++;
            }
            if (check == 0)
            {
                new Exception();
            }
        
        }
    }
}

