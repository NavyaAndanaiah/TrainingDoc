﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MMM
{
    class Program
    {
        static void Main(string[] args)
        {
            {
                int n;
                int sum = 0;
                double sdsum = 0;
                Console.WriteLine("enter the no of elements");
                n = Int32.Parse(Console.ReadLine());
                int[] arr = new int[n];
                for (int i = 0; i < n; i++)
                {
                    arr[i] = int.Parse(Console.ReadLine());
                    sum = sum + arr[i];
                    sdsum = sdsum + (arr[i] * arr[i]);
                }
                /* for (int i = 0; i < n; i++)
                 {*/
                //       Console.WriteLine(sdsum);

                meancal(sum, n);
                mediancal(arr, n);
                sdcal(sdsum, n);
            }
        }

        public static void meancal(int sum, int n)
        {
            double mean;
            mean = sum / n;
            Console.WriteLine($"the mean is {mean}");
            Console.ReadLine();
        }

        public static void mediancal(int[] arr, int n)
        {
            int mid = n / 2;
            if (n % 2 == 0)
            {
                Console.WriteLine($"the median is {arr[mid]} and {arr[mid + 1]}");
                Console.ReadLine();
            }
            else
            {
                Console.WriteLine($"the median is {arr[mid]}");
                Console.ReadLine();
            }

        }

        public static void sdcal(double sdsum, int n)
        {
            double v;
            double sd;

            v = sdsum / n;

            sd = Math.Sqrt(v);
            Console.WriteLine($"the standard deviation is { sd}");
            Console.ReadLine();
        }
    }
}
