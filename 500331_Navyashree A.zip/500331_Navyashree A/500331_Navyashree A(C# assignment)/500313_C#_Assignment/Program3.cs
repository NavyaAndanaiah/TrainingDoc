﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigitSum
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;
            Console.WriteLine("Enter the Number:");
            int num = int.Parse(Console.ReadLine());
            while (num > 0)
            {
                int temp = num % 10;
                sum = sum + temp;
                num = num / 10;
            }
                Console.WriteLine("The sum of digit is"+sum);
                Console.ReadLine();
                      



        }
    }
}
