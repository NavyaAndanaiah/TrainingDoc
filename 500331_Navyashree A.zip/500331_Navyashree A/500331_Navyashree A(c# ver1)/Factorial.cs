﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factorial
{
    class Program
    {
        static void Main(string[] args)
        {
            while(true)
            {
                int val=0;
                Console.WriteLine("Enter your number");
                if (int.TryParse(Console.ReadLine(), out val))
                {
                    Console.Clear();
                    Console.WriteLine("{0,-15} {1,20} \n","Number","Factorial");
                    while (val>0)
                    {
                        int res = 1;
                        int i = val;
                        while(i>0)
                        {
                            res = res * i;
                            i--;
                        }
                        Console.WriteLine("{0,-15} {1,20}\n", val, res);
                        val--;
                    }
                    break;
                }
                else
                {
                    Console.WriteLine("Errrorr in typing! Input the value again!!");
                }
            }
            Console.ReadLine();
        }

    }
}
