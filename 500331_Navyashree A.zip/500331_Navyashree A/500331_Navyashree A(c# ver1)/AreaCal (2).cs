﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Speech.Synthesis;

namespace AreaCal
{
    class Program
    {
        static SpeechSynthesizer reader = new SpeechSynthesizer();
        static void Main(string[] args)
        {
            Console.WriteLine("Enter area to be calculated for");
            reader.Speak("Enter area to be calculated for");
            Console.WriteLine("1.Rectangle\n2.Triangle");
            int choice = int.Parse(Console.ReadLine());
            var values = EnterValues();
            var calarea = CalculateAreas(values.Item1, values.Item2);
            switch (choice)
            {
                case 1:
                    Console.WriteLine($"Area for Rectangle is {calarea.Item1}");
                    break;
                case 2:
                    Console.WriteLine($"Area for Rectangle is {calarea.Item2}");
                    break;
            }
            Console.ReadLine();
        }
        public static Tuple<double, double> CalculateAreas(double a,double b)
        {
            double rectangle = a * b;
            double triangle = rectangle / 2;
            return new Tuple<double, double>(rectangle, triangle);
        }
        public static Tuple<double,double> EnterValues()
        {
            Console.WriteLine("enter the length");
            double m = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("enter the breadth");
            double n = Convert.ToDouble(Console.ReadLine());
            return new Tuple<double,double>(m,n);
        }
    }
}
       
    

