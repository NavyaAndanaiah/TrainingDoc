﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SumofDigits
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your number");
            int num = Convert.ToInt32(Console.ReadLine());
            int res = 0;
            int i = num;
            while (i > 0)
            {
                res = res + i % 10;
                i = i / 10;
            }
            Console.Clear();
            Console.WriteLine($"The sum of digits of {num} is {res}");
            Console.ReadLine();
        }
    }
}
