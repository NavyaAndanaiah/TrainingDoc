﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace ArraySorting
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the value in dollars");
            double US_dollar = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Convert the currency into \n 1.Indian Rupee \n 2.British pound");
            int choice = Convert.ToInt32(Console.ReadLine());
            double res = 0;
            switch (choice)
            {
                case 1: res = ConvertToRupee(US_dollar);
                        Console.WriteLine($"${US_dollar} is equivalent to Rs.{res}");
                        break;
                case 2: res = ConvertToPound(US_dollar);
                        Console.WriteLine($"${US_dollar} is equivalent to £{res}");
                        break;
            }
            Console.ReadKey();
        }

        private static double ConvertToPound(double uS_dollar)
        {
            return 0.81 * uS_dollar;
        }

        private static double ConvertToRupee(double uS_dollar)
        {
            return 65.48 * uS_dollar;
        }
       
    }
}
