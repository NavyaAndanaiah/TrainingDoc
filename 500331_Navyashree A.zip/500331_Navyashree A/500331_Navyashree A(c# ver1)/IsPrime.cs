﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimeNo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a Number : ");
            int num;
            num = Convert.ToInt32(Console.ReadLine());
            bool res = IsPrime(num);
            if(res)
            {
                Console.WriteLine("It's a prime no.");
            }
            else
            {
                Console.WriteLine("It's not a prime no.");

            }
            Console.ReadLine();
        }

        private static bool IsPrime(int num)
        {
            for (int i = 1; i <= num / 2; i++)
            {
                if (num % i == 0)
                {
                    return false;
                }
            }
            return true;
        }
    }
}
