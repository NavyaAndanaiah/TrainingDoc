﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pascal
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number of rows you wish to see in pascal triangle\n");
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {

                for (int c = 0; c <= (n - i - 2); c++)
                    Console.Write(" ");

                for (int c = 0; c <= i; c++)
                    Console.Write(" " + (factorial(i) / (factorial(c) * factorial(i - c))));

                Console.WriteLine("\n");
            }
            Console.ReadLine();

        }
        public static int factorial(int n)
        {
            int c;
            int result = 1;

            for (c = 1; c <= n; c++)
                result = result * c;

            return result;
        }
    }
}
