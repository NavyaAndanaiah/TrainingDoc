create database BookShop;

create table Books
(
  isbnNumber int not null primary key,
  title nvarchar(20) not null,
  author nvarchar(20) not null,
  price int not null,
  inStock bit not null 
  )

  insert into Books values
  (1,'Physics1','A',250,1),
  (2,'Physics2','B',250,1),
  (3,'Physics3','C',250,1),
  (4,'Physics4','D',250,1),
  (5,'Physics5','E',250,1),
  (6,'Chemistry1','F',250,1),
  (7,'Chemistry2','G',250,1),
  (8,'Chemistry3','H',250,1),
  (9,'Chemistry4','I',250,1),
  (10,'Chemistry5','J',250,1),
  (11,'Mathematics1','K',250,1),
  (12,'Mathematics2','L',250,1),
  (13,'Mathematics3','M',250,1),
  (14,'Mathematics4','N',250,1),
  (15,'Mathematics5','O',250,1)

  select * from Books