﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CaseleteOnBookShop
{
    class BooksOnAsubject : Book, ISalestax
    {
        public override string ToString()
        {
            return isbnNumber.ToString() + "\t" + title.ToString() + "\t" + author.ToString() + "\t" + price.ToString() +
                "\t" + inStock.ToString();
        }

        public void Add_book()
        {
            DataClasses1DataContext db = new DataClasses1DataContext();
            Book bk = new Book();
            Console.WriteLine("Enter isbnNumber , title, author, price");
            bk.isbnNumber = int.Parse(Console.ReadLine());
            bk.title = Console.ReadLine();
            bk.author = Console.ReadLine();
            bk.price = int.Parse(Console.ReadLine());
            db.Books.InsertOnSubmit(bk);
            db.SubmitChanges();
        }                         
       
        public void delete_book()
        {
            DataClasses1DataContext db = new DataClasses1DataContext();
            Console.WriteLine("Enter the isbnNumber");
            int a = int.Parse(Console.ReadLine());
            var c = db.Books.Where(b => b.isbnNumber == a).FirstOrDefault();
            db.Books.DeleteOnSubmit(c);
            db.SubmitChanges();
        }

        public void display_allbooks()
        {
            DataClasses1DataContext db = new DataClasses1DataContext();
            foreach (var item in db.Books)
            {
                Console.WriteLine($"{item.isbnNumber} {item.title} {item.author} {item.price}");
            }
        }

        public void modify_price()
        {
            int newprice;
            int booknum;
            DataClasses1DataContext db = new DataClasses1DataContext();
            Console.Write("Enter book number: ");
            booknum = int.Parse(Console.ReadLine());
            var a = db.Books.Where(b => b.isbnNumber == booknum).FirstOrDefault();
            Console.Write("Enter New Price: ");
            newprice = int.Parse(Console.ReadLine());
            a.price = newprice;
            db.SubmitChanges();
        }
        
        public void searchByAuthor()
        {
            try
            {
                DataClasses1DataContext db = new DataClasses1DataContext();
                Console.WriteLine("Enter the Author");
                var data = db.Books.Where(e => e.author == Console.ReadLine()).FirstOrDefault();
                Console.WriteLine(data.author);
            }
            catch(Exception ex)
            {
                Console.WriteLine("Author is not available");
            }

        }

        public void searchByTitle()
        {
            try
            {
                DataClasses1DataContext db = new DataClasses1DataContext();
                Console.WriteLine("Enter the Title");
                var data = db.Books.Where(e => e.title == Console.ReadLine()).FirstOrDefault();
                Console.WriteLine(data.title);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Title is not available");
            }
        }

        public void check_available()
        {
           try
            {
                DataClasses1DataContext db = new DataClasses1DataContext();
                Console.WriteLine("Enter Title");
                string t = Console.ReadLine();

                var result = db.Books.Where(item => item.title == t).FirstOrDefault();

                if (result != null)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine(" Book is Available");
                    Console.ResetColor();
                    Console.WriteLine($"isbn Number :{ result.isbnNumber}\n  Title     :{result.title}\n  Author    :{result.author}\n  Price     :{ result.price}\n  inStock   :{ result.inStock}\n");
                }
                else
                {
                    throw (new NotAvailable());
                }
            }
            catch (NotAvailable ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(ex.msg1());
                Console.ResetColor();
            }
        }

        public void calculate_SalesTax()
        {
            DataClasses1DataContext db = new DataClasses1DataContext();
            foreach (var item in db.Books)
            {
                Console.WriteLine($"Book {item.title} tax {item.price*0.045}");
            }
           
        }

    }
}
