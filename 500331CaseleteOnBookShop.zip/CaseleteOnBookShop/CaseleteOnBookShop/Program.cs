﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CaseleteOnBookShop
{
    class program
    {
        static void Main(string[] args)
        {
            string confirm;
            DataClasses1DataContext db = new DataClasses1DataContext();
            BooksOnAsubject b = new BooksOnAsubject();
            
            do
            {
                Console.WriteLine("---------------------------------------------------------");
                Console.WriteLine(" 1:Add Book\n 2:Delete Book\n 3:Display all books\n 4:Modify the price of a book\n 5:Search by author\n 6:Search by title\n 7:Calculate Sales Tax\n 8:Check Availability\n 9:Exit");
                Console.WriteLine("---------------------------------------------------------");
                int i = GetInt("Enter the choice");
                switch (i)
                {
                    case 1:
                        b.Add_book();
                        break;
                    case 2:
                        b.delete_book();
                        break;
                    case 3:
                        b.display_allbooks();
                        break;
                    case 4:
                        b.modify_price();
                        break;
                    case 5:
                        b.searchByAuthor();
                        break;
                    case 6:
                        b.searchByTitle();
                        break;
                    case 7:
                        b.calculate_SalesTax();
                        break;
                    case 8:
                        b.check_available();
                        break;
                    case 9:
                        break;
                }
                Console.WriteLine("Enter to Y or y continue");
                confirm = Console.ReadLine().ToUpper();

            } while (confirm == "Y");
        }
        private static int GetInt(string message)
        {
            int val = 0;
            while (true)
            {

                Console.WriteLine(message);
                if (int.TryParse(Console.ReadLine(), out val))
                    break;
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("The entered number is not in correct format please try again");
                Console.ResetColor();
            }
            return val;
        }
    }
}
